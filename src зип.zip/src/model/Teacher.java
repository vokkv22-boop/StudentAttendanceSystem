package model;

public class Teacher extends User {

    public Teacher(int id, String name) {
        super(id, name);
    }
}

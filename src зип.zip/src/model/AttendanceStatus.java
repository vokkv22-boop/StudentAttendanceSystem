package model;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE,
    EXCUSED
}

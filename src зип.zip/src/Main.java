import manager.MenuManager;

public class Main {
    public static void main(String[] args) {
        MenuManager menu = new MenuManager();
        menu.start();
    }
}

